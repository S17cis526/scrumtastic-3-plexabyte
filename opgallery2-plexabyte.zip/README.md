# Scrumtastic
Scrumtastic is a web-based agile development tool for [SCRUM](https://en.wikipedia.org/wiki/Scrum_(software_development))-like software development processes.  It maintains a product backlog, provides a sprint task board, and automatically generates a sprint burndown and release burnup charts.

TODO:
* Image upload works only on MS Edge
* Album Art doesn't show until server restart
* Style changes needed


* Users & Authentication
* Projects
* Story Cards
* Project Backlog
* Sprint Planning
* Task Board
* Burndown Chart
* Burnup Chart
* Music
