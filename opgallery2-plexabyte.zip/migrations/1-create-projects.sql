CREATE TABLE projects (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  artist TEXT,
  genre TEXT,
  filename TEXT
);
