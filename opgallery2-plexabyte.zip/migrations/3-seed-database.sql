INSERT INTO projects (name, artist, genre))
VALUES ("Testy", "ArTest", "Jazz");
